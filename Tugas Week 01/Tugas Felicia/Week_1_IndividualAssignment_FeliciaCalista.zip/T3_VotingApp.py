# Terdapat 3 kandidat  
candidate = [1, 2, 3]

voting = {1: 0, 2: 0, 3: 0}

# Menginput pilihan menggunakan looping
while True:
    try:
        while True:
            choice = int(input('Your choice: '))
           
            if choice != 0 and choice in candidate:
                if choice in voting:
                    voting[choice] += 1
                else:
                    voting[choice] = 1
            
            # Apabila menginput 0, maka keluar dari loop
            elif choice == 0:
                voting_result = []
                for key in voting:
                    voting_result.append(voting[key])

                sum_value = 0
                for result in voting_result:
                    sum_value += result
                
                voting_result_in_percentage = []
                for result in voting_result:
                    voting_result_in_percentage.append((result/sum_value) * 100)
                
                print(f'1: {voting_result_in_percentage[0]}%, 2: {voting_result_in_percentage[1]}%, 3: {voting_result_in_percentage[2]}%')
            
            else:
                print('Insert candidate 1-3')
    
    # Tidak boleh menginput angka selain 0 - 3
    except ValueError:
        pass