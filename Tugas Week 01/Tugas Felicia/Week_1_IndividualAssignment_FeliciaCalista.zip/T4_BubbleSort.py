def main():
    old_list = input_data()
    copied_old_list = old_list[:]
    new_list = sorted_number(copied_old_list)
    print(output(old_list, new_list)) 

def input_data():
    list_number = []
    number_amount = int(input('How many number: '))
    for number in range(number_amount):
        number = int(input('Number: '))
        list_number.append(number)
    return list_number

def sorted_number(list_number):
    for i in range(len(list_number)):
        for i in range(len(list_number) - 1):
            if list_number[i] > list_number[i + 1]:
                list_number[i], list_number[i + 1] = list_number[i + 1],  list_number[i]
    return list_number

def output(old, new):
    return f'Before sorting: {old}, After sorting: {new}'

if __name__ == '__main__':
    main()