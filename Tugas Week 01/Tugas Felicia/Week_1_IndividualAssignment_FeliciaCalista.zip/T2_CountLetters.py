word = 'tomorrow'

# Menghitung berapa jumlah letters pada sebuah string
histo = dict()

for letter in word:
    if letter in histo:
        histo[letter] += 1
    else:
        histo[letter] = 1

print(f'Counted words: {histo}')