# Terdapat dua buah list, yaitu list flavour dan list harga
def main():
    ice_cream_flavour = ['chocolate', 'strawberry', 'vanila']
    ice_cream_price = ['$3', '$2', '$1']
    request = input('What to do: ')
    if request == 'create':
        print(add_flavour_and_price(ice_cream_flavour, ice_cream_price))
    elif request == 'read':
        price_lists = price_list(ice_cream_flavour, ice_cream_price)
        print(show_price(price_lists))
    elif request == 'update':
        price_lists = price_list(ice_cream_flavour, ice_cream_price)
        print(update(price_lists))
    elif request == 'delete':
        price_lists = price_list(ice_cream_flavour, ice_cream_price)
        print(delete(price_lists))

# Create (append) = function untuk menambahkan flavour dan harga 
def add_flavour_and_price(ice_cream_flavour, ice_cream_price):
    new_flavour = input('New Flavour: ')
    new_price = input('Price of new flavour: ')
    ice_cream_flavour.append(new_flavour)
    ice_cream_price.append(new_price)
    return ice_cream_flavour, ice_cream_price

# Read = menampilkan harga saat ketika menginput flavour (menggunakan dict)
def price_list(ice_cream_flavour, ice_cream_price):
    ice_cream_price_list = {}
    for i in range(len(ice_cream_flavour)):
        ice_cream_price_list[ice_cream_flavour[i]] = ice_cream_price[i]
    return ice_cream_price_list

def show_price(ice_cream_price_list):
    wanted_flavour = input('What flavour: ')
    return ice_cream_price_list[wanted_flavour]

# Update = (mis. Oreo tidak laku, upgrade harganya menjadi lebih murah)        
def update(ice_cream_price_list):
    ice_cream_flavour_update = input('Needed update ice creams flavour: ')
    updated_ice_cream_price = input('New price: ')
    ice_cream_price_list[ice_cream_flavour_update] = updated_ice_cream_price
    return ice_cream_price_list

# D = delete 
def delete(ice_cream_price_list):
    delete_ice_cream_flavour = input('Remove Flavour: ')
    ice_cream_price_list.pop(delete_ice_cream_flavour)
    return ice_cream_price_list

if __name__ == '__main__':
    main()