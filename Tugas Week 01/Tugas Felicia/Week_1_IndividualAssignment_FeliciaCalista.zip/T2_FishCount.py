# Fungsi random digunakan untuk mengisi Array
import random

fish_time = []

for i in range(24):
    fish_amount = random.randint(0, 100)
    fish_time.append(fish_amount)

print(fish_time)

# 1. Berapa jumlah ikan terbanyak?
most_fish = 0

for i in range(24):
    if fish_time[i] > most_fish:
        most_fish = fish_time[i]

print(f'Most: {most_fish}')

# 2. Berapa jumlah ikan yang paling sedikit?
least_fish = most_fish

for i in range(24):
    if fish_time[i] < least_fish:
        least_fish = fish_time[i]

print(f'Least: {least_fish}')

# 3. Jumlah ikan terbanyak lewat pada jam berapa?
for i in range(24):
    if most_fish == fish_time[i]:
        print(f'Most fish time: {i}')
        break

# 4. Jumlah ikan paling sedikit lewat pada jam berapa?
for i in range(24):
    if least_fish == fish_time[i]:
        print(f'Least fish time: {i}')
        break

# Ada masalah: terdapat sensor yang rusak pada jam 1 - 22
broken_censor_time = random.randint(1, 22)
fish_time[broken_censor_time] = -1

print(fish_time)

# Menambahkan dua angka yang berada di antara (sebelum dan sesudah) index sensor yang rusak. Kemudian, dibagi dua untuk mengisi array pada index tersebut 
for i in range(24):
    if fish_time[i] == -1:
        broken_censor_fish_amount = (fish_time[i-1] + fish_time[i+1]) // 2 # // (floor division) > nearest amount when its devided
        fish_time[i] == broken_censor_fish_amount
        break

print(f'Broken censor: {broken_censor_time}, Fish amount: {broken_censor_fish_amount}')
